
import * as THREE from 'three'
import { useEffect, useRef } from 'react'
import { useGLTF, useAnimations } from '@react-three/drei'
import type { ThreeElements } from '@react-three/fiber'

type ActionName = 'Object_0'

interface GLTFAction extends THREE.AnimationClip {
  name: ActionName
}

type GLTFResult = {
  nodes: {
    Cube039_0: THREE.Mesh
    Cube038_0: THREE.Mesh
    Cube037_0: THREE.Mesh
    Cube036_0: THREE.Mesh
    Cube035_0: THREE.Mesh
    Cube034_0: THREE.Mesh
    Cube033_0: THREE.Mesh
    Cube032_0: THREE.Mesh
    Cube031_0: THREE.Mesh
    Cube030_0: THREE.Mesh
    Cube029_0: THREE.Mesh
    Cube028_0: THREE.Mesh
    Cube027_0: THREE.Mesh
    Cube026_0: THREE.Mesh
    Cube025_0: THREE.Mesh
    Cube024_0: THREE.Mesh
    Cube023_0: THREE.Mesh
    Cube022_0: THREE.Mesh
    Cube021_0: THREE.Mesh
    Cube020_0: THREE.Mesh
    Cube019_0: THREE.Mesh
    Cube018_0: THREE.Mesh
    Cube017_0: THREE.Mesh
    Cube016_0: THREE.Mesh
    Cube015_0: THREE.Mesh
    Cube014_0: THREE.Mesh
    Cube013_0: THREE.Mesh
    Cube012_0: THREE.Mesh
    Cube011_0: THREE.Mesh
    Cube010_0: THREE.Mesh
    Cube009_0: THREE.Mesh
    Cube008_0: THREE.Mesh
    Cube007_0: THREE.Mesh
    Cube006_0: THREE.Mesh
    Cube005_0: THREE.Mesh
    Cube004_0: THREE.Mesh
    Cube003_0: THREE.Mesh
    Cube002_0: THREE.Mesh
    Cube001_0: THREE.Mesh
    Cube_0: THREE.Mesh
    Sun_0: THREE.Mesh
    Moon_0: THREE.Mesh
    Diamond_Core_0: THREE.Mesh
    Core_0: THREE.Mesh
    IceTree_0: THREE.Mesh
    Circle002_0: THREE.Mesh
    Circle001_0: THREE.Mesh
    lava_0: THREE.Mesh
    ground_0: THREE.Mesh
    Ice_0: THREE.Mesh
    House_0: THREE.Mesh
    Cube042_0: THREE.Mesh
    Sphere_0: THREE.Mesh
    Plane005_0: THREE.Mesh
    Sphere001_0: THREE.Mesh
  }
  materials: {
    PaletteMaterial008: THREE.MeshStandardMaterial
    PaletteMaterial007: THREE.MeshStandardMaterial
    PaletteMaterial009: THREE.MeshStandardMaterial
    PaletteMaterial010: THREE.MeshStandardMaterial
    PaletteMaterial005: THREE.MeshStandardMaterial
    PaletteMaterial001: THREE.MeshStandardMaterial
    PaletteMaterial002: THREE.MeshStandardMaterial
    PaletteMaterial003: THREE.MeshStandardMaterial
    PaletteMaterial004: THREE.MeshStandardMaterial
    PaletteMaterial006: THREE.MeshStandardMaterial
    PaletteMaterial011: THREE.MeshStandardMaterial
    PaletteMaterial012: THREE.MeshStandardMaterial
    PaletteMaterial013: THREE.MeshStandardMaterial
    PaletteMaterial014: THREE.MeshStandardMaterial
  }
  animations: GLTFAction[]
}

export function Planet4(props: ThreeElements['group']) {
  const group = useRef<THREE.Group>(null)
  const { nodes, materials, animations } = useGLTF('/models/planet_4_optimized.glb') as unknown as GLTFResult
  const { actions } = useAnimations(animations, group)

  useEffect(() => {
    actions?.Object_0?.play();
  }, [actions]);

  return (
    <group ref={group} {...props} dispose={null}>
      <group name="Sketchfab_Scene">
        <group name="Root" rotation={[-Math.PI / 2, 0, 0]}>
          <group name="Debris" rotation={[0.258, -0.002, 0.787]} scale={1.079}>
            <group name="Cube039" position={[0, 0, -0.63]} rotation={[0, 0, -3.019]} scale={0.223}>
              <mesh name="Cube039_0" geometry={nodes.Cube039_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube038" position={[0, 0, -0.348]} rotation={[-Math.PI, 0, -0.379]} scale={[-0.392, 0.263, 1.2]}>
              <mesh name="Cube038_0" geometry={nodes.Cube038_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube037" rotation={[-Math.PI, 0, -1.3]} scale={[-0.392, 0.263, 1.2]}>
              <mesh name="Cube037_0" geometry={nodes.Cube037_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube036" position={[0, 0, -0.885]} rotation={[-Math.PI, 0, -1.919]} scale={[-0.41, 0.276, 1.255]}>
              <mesh name="Cube036_0" geometry={nodes.Cube036_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube035" position={[0, 0, -0.553]} rotation={[-Math.PI, 0, -2.624]} scale={[-0.41, 0.276, 1.255]}>
              <mesh name="Cube035_0" geometry={nodes.Cube035_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube034" position={[0, 0, -0.111]} rotation={[-Math.PI, 0, 3.114]} scale={[-0.392, 0.263, 1.2]}>
              <mesh name="Cube034_0" geometry={nodes.Cube034_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube033" position={[0, 0, -0.757]} rotation={[-Math.PI, 0, 2.775]} scale={[-0.392, 0.263, 1.2]}>
              <mesh name="Cube033_0" geometry={nodes.Cube033_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube032" position={[0, 0, -0.098]} rotation={[-Math.PI, 0, 2.467]} scale={[-0.392, 0.263, 1.2]}>
              <mesh name="Cube032_0" geometry={nodes.Cube032_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube031" position={[0, 0, -0.782]} rotation={[-Math.PI, 0, 1.971]} scale={[-0.41, 0.276, 1.255]}>
              <mesh name="Cube031_0" geometry={nodes.Cube031_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube030" rotation={[0, 0, 2.19]} scale={0.204}>
              <mesh name="Cube030_0" geometry={nodes.Cube030_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube029" position={[0, 0, -0.505]} rotation={[0, 0, 2.341]} scale={0.223}>
              <mesh name="Cube029_0" geometry={nodes.Cube029_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube028" position={[0, 0, -0.815]} rotation={[0, 0, 2.957]} scale={0.223}>
              <mesh name="Cube028_0" geometry={nodes.Cube028_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube027" position={[0, 0, -0.21]} rotation={[0, 0, -2.673]} scale={0.223}>
              <mesh name="Cube027_0" geometry={nodes.Cube027_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube026" position={[0, 0, -0.191]} rotation={[0, 0, -1.932]} scale={0.233}>
              <mesh name="Cube026_0" geometry={nodes.Cube026_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube025" position={[0, 0, -0.39]} rotation={[0, 0, -1.809]} scale={0.223}>
              <mesh name="Cube025_0" geometry={nodes.Cube025_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube024" position={[0, 0, -0.147]} rotation={[0, 0, -1.18]} scale={0.223}>
              <mesh name="Cube024_0" geometry={nodes.Cube024_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube023" position={[0, 0, -0.772]} rotation={[0, 0, -0.641]} scale={0.223}>
              <mesh name="Cube023_0" geometry={nodes.Cube023_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube022" position={[0, 0, -0.39]} rotation={[0, 0, -0.512]} scale={0.223}>
              <mesh name="Cube022_0" geometry={nodes.Cube022_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube021" position={[0, 0, -0.791]} rotation={[0, 0, 0.155]} scale={0.204}>
              <mesh name="Cube021_0" geometry={nodes.Cube021_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube020" position={[0, 0, 0.026]} rotation={[0, 0, 0.714]} scale={0.233}>
              <mesh name="Cube020_0" geometry={nodes.Cube020_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube019" position={[0, 0, -1.158]} rotation={[0, 0, 1.063]} scale={0.223}>
              <mesh name="Cube019_0" geometry={nodes.Cube019_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube018" position={[0, 0, -0.103]} rotation={[0, 0, 1.594]} scale={0.204}>
              <mesh name="Cube018_0" geometry={nodes.Cube018_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube017" rotation={[0, 0, 1.844]} scale={0.746}>
              <mesh name="Cube017_0" geometry={nodes.Cube017_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube016" rotation={[0, 0, 2.515]} scale={0.683}>
              <mesh name="Cube016_0" geometry={nodes.Cube016_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube015" position={[0, 0, -0.295]} rotation={[0, 0, -3.107]} scale={0.778}>
              <mesh name="Cube015_0" geometry={nodes.Cube015_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube014" position={[0, 0, -0.49]} rotation={[0, 0, -2.28]} scale={0.714}>
              <mesh name="Cube014_0" geometry={nodes.Cube014_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube013" position={[0, 0, -0.764]} rotation={[0, 0, -1.313]} scale={0.778}>
              <mesh name="Cube013_0" geometry={nodes.Cube013_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube012" position={[0, 0, -0.455]} rotation={[0, 0, -0.038]} scale={0.714}>
              <mesh name="Cube012_0" geometry={nodes.Cube012_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube011" rotation={[0.389, 0.463, 0.715]} scale={0.578}>
              <mesh name="Cube011_0" geometry={nodes.Cube011_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube010" position={[0, 0, 0.239]} rotation={[-0.323, 0.509, 2.059]} scale={0.554}>
              <mesh name="Cube010_0" geometry={nodes.Cube010_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube009" position={[0, 0, -0.309]} rotation={[-0.494, -0.347, -2.692]} scale={0.578}>
              <mesh name="Cube009_0" geometry={nodes.Cube009_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube008" position={[0, 0, -0.141]} rotation={[-0.277, -0.534, -2.193]} scale={0.53}>
              <mesh name="Cube008_0" geometry={nodes.Cube008_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube007" position={[0, 0, -0.216]} rotation={[0.396, -0.457, -0.925]} scale={0.578}>
              <mesh name="Cube007_0" geometry={nodes.Cube007_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube006" position={[0, 0, 0.217]} rotation={[0.576, -0.163, -0.358]} scale={0.578}>
              <mesh name="Cube006_0" geometry={nodes.Cube006_0.geometry} material={materials.PaletteMaterial008} />
            </group>
            <group name="Cube005" position={[0, 0, 0.51]} rotation={[0, 0, 0.378]} scale={0.778}>
              <mesh name="Cube005_0" geometry={nodes.Cube005_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube004" position={[0, 0, 0.23]} rotation={[0, 0, 1.29]} scale={0.714}>
              <mesh name="Cube004_0" geometry={nodes.Cube004_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube003" position={[0, 0, 0.51]} rotation={[0, 0, 2.75]} scale={0.778}>
              <mesh name="Cube003_0" geometry={nodes.Cube003_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube002" position={[0, 0, 0.206]} rotation={[0, 0, -2.807]} scale={0.778}>
              <mesh name="Cube002_0" geometry={nodes.Cube002_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube001" position={[0, 0, 0.641]} rotation={[0, 0, -1.566]} scale={0.778}>
              <mesh name="Cube001_0" geometry={nodes.Cube001_0.geometry} material={materials.PaletteMaterial007} />
            </group>
            <group name="Cube" position={[0, 0, 0.618]} rotation={[0, 0, -Math.PI / 4]} scale={0.714}>
              <mesh name="Cube_0" geometry={nodes.Cube_0.geometry} material={materials.PaletteMaterial007} />
            </group>
          </group>
          <group name="Sun_&_Moon" rotation={[0.785, 0, 0]}>
            <group name="Sun">
              <mesh name="Sun_0" geometry={nodes.Sun_0.geometry} material={materials.PaletteMaterial009} />
            </group>
            <group name="Moon">
              <mesh name="Moon_0" geometry={nodes.Moon_0.geometry} material={materials.PaletteMaterial010} />
            </group>
          </group>
          <group name="Empty" position={[0, 8.702, 0.089]} />
        </group>
        <group name="Core" rotation={[-1.309, 0, 0]} scale={1.485}>
          <group name="Diamond_Core" scale={[0.209, 0.353, 0.353]}>
            <mesh name="Diamond_Core_0" geometry={nodes.Diamond_Core_0.geometry} material={materials.PaletteMaterial005} />
          </group>
        </group>
        <mesh name="Core_0" geometry={nodes.Core_0.geometry} material={materials.PaletteMaterial001} rotation={[-1.309, 0, 0]} scale={1.485} />
        <mesh name="IceTree_0" geometry={nodes.IceTree_0.geometry} material={materials.PaletteMaterial002} position={[-0.187, 9.263, 2.947]} rotation={[-1.309, 0, 1.236]} scale={0.605} />
        <mesh name="Circle002_0" geometry={nodes.Circle002_0.geometry} material={materials.PaletteMaterial003} position={[-0.027, 7.843, 2.09]} rotation={[1.944, 0.038, -1.239]} scale={[-1.946, 1.946, 1.946]} />
        <mesh name="Circle001_0" geometry={nodes.Circle001_0.geometry} material={materials.PaletteMaterial004} position={[-0.027, 7.764, 2.069]} rotation={[1.944, 0.038, -1.239]} scale={[-1.946, 1.946, 1.946]} />
        <mesh name="lava_0" geometry={nodes.lava_0.geometry} material={materials.PaletteMaterial006} position={[0, -0.312, -0.083]} rotation={[1.833, 0, 0]} scale={4.575} />
        <mesh name="ground_0" geometry={nodes.ground_0.geometry} material={materials.PaletteMaterial007} position={[0, -0.312, -0.083]} rotation={[1.833, 0, 0]} scale={4.569} />
        <mesh name="Ice_0" geometry={nodes.Ice_0.geometry} material={materials.PaletteMaterial008} position={[0, 0.237, 0.064]} rotation={[1.833, 0, 0]} scale={[4.575, 4.575, 4.408]} />
        <mesh name="House_0" geometry={nodes.House_0.geometry} material={materials.PaletteMaterial011} position={[0.094, 4.959, -0.935]} rotation={[-1.917, -0.171, -0.031]} scale={0.161} />
        <mesh name="Cube042_0" geometry={nodes.Cube042_0.geometry} material={materials.PaletteMaterial012} position={[-0.371, 5.902, -1.655]} rotation={[-2.14, -0.16, -0.068]} scale={[0.096, 0.096, 0.328]} />
        <mesh name="Sphere_0" geometry={nodes.Sphere_0.geometry} material={materials.PaletteMaterial013} position={[0.534, 5.272, -0.954]} rotation={[-1.734, 1.397, -0.18]} scale={0.019} />
        <mesh name="Plane005_0" geometry={nodes.Plane005_0.geometry} material={materials.PaletteMaterial014} position={[0.092, -10.721, -1.623]} rotation={[3.097, 0.113, 3.109]} scale={[-0.437, 0.409, 0.436]} />
        <mesh name="Sphere001_0" geometry={nodes.Sphere001_0.geometry} material={materials.PaletteMaterial005} position={[-0.205, -9.866, -1.503]} rotation={[-2.988, 0.022, 0.023]} scale={[0.041, 0.038, 0.041]} />
      </group>
    </group>
  )
}

useGLTF.preload('/models/planet_4_optimized.glb')
